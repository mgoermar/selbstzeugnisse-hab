<?php 
 header("Location: ludwig_rudolf-persName.html"); ?>